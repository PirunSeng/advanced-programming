import java.net.Socket;

public class TranslationThread extends Thread {
	
	public TranslationThread(Socket connection){
		
	}
	
  @Override
  public void run() {
  	// TODO Auto-generated method stub
  	super.run();
  }
}
